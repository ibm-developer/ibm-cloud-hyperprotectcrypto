Readme file for IBM ACSP PKCS#11 Client
---------------------------------------

Remark!
-------
	Please refer to the documentation for instructions on how to use
	the ACSP PKCS#11 client to execute PKCS#11 functions.  

version 1.5.2.0
---------------------------------------------------------
    - Update the embedded OpenSSL to 1.0.2j
    - deprecated client.connection.io.timeout in favor of client.connection.io.timeout.ms
	- Added support for client.connect.timeout.ms

version 1.4.1.0
---------------------------------------------------------
    - Defect 10598: Add support for alternate Auto configuration hosts
    - Update the embedded OpenSSL to 1.0.1l
    - Moved initialization from library-load to first-call.
	
version 1.4.0.1
---------------------------------------------------------
	- Added error-message 50410 to notify about the ssl.truststore not specified in configuration.
	- Added warn-message 50411 to notify about invalid ssl.protocol configuration

version 1.4.0.0
---------------------------------------------------------
	- First release of the PKCS#11 client
