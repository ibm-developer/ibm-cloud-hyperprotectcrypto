/*********************************************************************/
/*                                                                   */
/* Module Name: pkcs11_sample.c                                      */
/*                                                                   */
/* DESCRIPTIVE NAME: ACSP PKCS11 C language source code example      */
/*                                                                   */
/*-------------------------------------------------------------------*/
/*                                                                   */
/* Licensed Materials - Property of IBM                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2016-2017 All Rights Reserved             */
/*                                                                   */
/* US Government Users Restricted Rights - Use duplication or        */
/* disclosure restricted by GSA ADP Schedule Contract with IBM Corp. */
/*                                                                   */
/*-------------------------------------------------------------------*/
/*                                                                   */
/*        NOTICE TO USERS OF THE SOURCE CODE EXAMPLES                */
/*                                                                   */
/* The source code examples provided by IBM are only intended to     */
/* assist in the development of a working software program. The      */
/* source code examples do not function as written: additional       */
/* code is required. In addition, the source code examples may       */
/* not compile and/or bind successfully as written.                  */
/*                                                                   */
/* International Business Machines Corporation provides the source   */
/* code examples, both individually and as one or more groups,       */
/* "as is" without warranty of any kind, either expressed or         */
/* implied, including, but not limited to the implied warranties of  */
/* merchantability and fitness for a particular purpose. The entire  */
/* risk as to the quality and performance of the source code         */
/* examples, both individually and as one or more groups, is with    */
/* you. Should any part of the source code examples prove defective, */
/* you (and not IBM or an authorized dealer) assume the entire cost  */
/* of all necessary servicing, repair or correction.                 */
/*                                                                   */
/* IBM does not warrant that the contents of the source code         */
/* examples, whether individually or as one or more groups, will     */
/* meet your requirements or that the source code examples are       */
/* error-free.                                                       */
/*                                                                   */
/* IBM may make improvements and/or changes in the source code       */
/* examples at any time.                                             */
/*                                                                   */
/* Changes may be made periodically to the information in the        */
/* source code examples; these changes may be reported, for the      */
/* sample code included herein, in new editions of the examples.     */
/*                                                                   */
/* References in the source code examples to IBM products, programs, */
/* or services do not imply that IBM intends to make these           */
/* available in all countries in which IBM operates. Any reference   */
/* to the IBM licensed program in the source code examples is not    */
/* intended to state or imply that IBM's licensed program must be    */
/* used. Any functionally equivalent program may be used.            */
/*                                                                   */
/*-------------------------------------------------------------------*/
/*                                                                   */
/* Sample program using pkcs11 cryptoki to create a digest           */
/*                                                                   */
/*********************************************************************/
#include <stdio.h>
#ifdef _WIN32
#include <Windows.h>
#else
#include <dlfcn.h>
#include <errno.h>
#include <string.h>
#endif
#include "cryptoki.h"

CK_FUNCTION_LIST_PTR GetProcAddr( char * dllFileName, char *functionName);

int main(int argc, char **argv) {

	CK_FUNCTION_LIST_PTR pFunctionList;
	CK_C_GetFunctionList pC_GetFunctionList;
	CK_SESSION_HANDLE hSession;
	CK_RV rv;
	char * dllFileName=NULL;
	CK_MECHANISM mechanism = {CKM_SHA_1, NULL_PTR, 0};

	if (argc >1){
		dllFileName=argv[1];
	}
	if (dllFileName==NULL){
		printf("No PKCS#11 library argument given\nUsage:\n\t%s <pkcs11-lib>\n",argv[0]);
		return 1;
	}

	pC_GetFunctionList = (CK_C_GetFunctionList)GetProcAddr( dllFileName, "C_GetFunctionList");

	if (pC_GetFunctionList== NULL) {
		printf("Cannot load cryptoki, using library %s\n", dllFileName);
		return 0;
	}

	rv = pC_GetFunctionList(&pFunctionList);

	if (rv!=CKR_OK || pFunctionList == NULL_PTR) {
		return rv;
	}

	rv = pFunctionList->C_Initialize(NULL);
	if (rv != CKR_OK && rv != CKR_CRYPTOKI_ALREADY_INITIALIZED) {
			printf("Endec(): C_Initialize failed, rv=0x%X\n", (unsigned int)rv);
			return rv;
	}
	rv = pFunctionList->C_OpenSession(0,CKF_SERIAL_SESSION|CKF_RW_SESSION,0,NULL,&hSession);
	if (rv != CKR_OK ) {
			printf("C_OpenSession failed, rv=0x%X\n", (unsigned int)rv);
			return rv;
	}

	rv = pFunctionList->C_DigestInit(hSession, &mechanism);
	if (rv==CKR_OK) {
		CK_BYTE pData[80];
		unsigned int i;
		CK_ULONG ulDataLen=sizeof(pData), ulDigestLen=80;
		CK_BYTE digest[80];
		for (i=0; i<sizeof(pData); i++) pData[i] = (CK_BYTE)i;

		rv = pFunctionList->C_Digest(hSession,pData, ulDataLen, digest, &ulDigestLen);
		printf("C_digest, rv=0x%X, ulDigestLen=%ld\n", (unsigned int)rv, ulDigestLen);
		if (rv==CKR_OK) {
			printf("Calculated digest is: ");
			for (i=0; i<ulDigestLen; i++){
				printf("%02X",(CK_BYTE)digest[i]);
			}
			printf("\n");
		}
	}
	pFunctionList->C_CloseSession(hSession);
	pFunctionList->C_Finalize(NULL);
	return 0;
}

CK_FUNCTION_LIST_PTR GetProcAddr( char * dllFileName, char *functionName) {
#ifdef _WIN32
	HMODULE module;
	CK_FUNCTION_LIST_PTR pFunctionAddr;
	module =  LoadLibrary(dllFileName);
#else
	void *module;
	CK_FUNCTION_LIST_PTR pFunctionAddr;
	module = dlopen(dllFileName,RTLD_NOW);
#endif
	if(module == NULL) {
#ifndef _WIN32
		printf("error: %s: %s\n", dllFileName, dlerror());
#endif
		printf("Error, could not load file %s, cannot continue\n", dllFileName);
		return NULL;
	}
	/* Get the list of the PKCS11 functions this token supports */
#ifdef _WIN32
	pFunctionAddr = (CK_FUNCTION_LIST_PTR)GetProcAddress(module, functionName);
#else
	pFunctionAddr = (CK_FUNCTION_LIST_PTR)dlsym(module, functionName);
#endif
	if (pFunctionAddr == NULL) {
		printf("Function %s not found, cannot continue\n", functionName);
	}
	return pFunctionAddr;
}
