HOW TO COMPILE THE SAMPLE PROGRAMS

The PKCS#11 interface is provided by the libacsp-pkcs11 library 
found in /usr/lib or /usr/lib64. Using symlinks, this library is identical to 
the libacsp-pkcs11.so.<version> library located in the /opt/ibm/acsp-pkcs11-client/lib directory.

To compile the sample program (sample.c), use the following commands: 

#Change directory to the pkcs11-client installation directory
cd /opt/ibm/acsp-pkcs11-client

#Compile
gcc -o bin/sample sample/sample.c -ldl

The compiled sample program will be generated in the bin directory.


HOW TO RUN THE SAMPLE PROGRAMS

The ACSP PKCS#11 client determines the location of its configuration file by checking
the ACSP_P11 environment variable. If not set, it will check the ACSP environment
variable. The provided configuration file is is located in the config folder. 
To run the sample-program set and export the variable:

ACSP_P11=/opt/ibm/acsp-pkcs11-client/config/acsp.properties
export ACSP_P11
LD_LIBRARY_PATH=/opt/ibm/acsp-pkcs11-client/lib
export LD_LIBRARY_PATH
bin/sample libacsp-pkcs11.so

Note: In the above example, an absolute path was used to identify the configuration file.
If the path is given as a relative path, it will be relative to the working directory of 
the program that uses the pkcs11-client. 

In case of runtime-errors, verify that the configuration file has been configured 
correctly. Especially the following options: 
client.autoconf.host, client.autoconf.port, client.connect.host, client.connect.port,
ssl.private.key, ssl.certificate, ssl.truststore


RELATED MATERIALS
Please refer to the ACSP CCA and PKCS#11 Programmers Guide (ACSP-2015) for further details 
on ACSP programming 